<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Crud extends CI_Controller
{
	function __construct(){
		parent:: __construct();
		$this->load->model('Model_crud');
	}

	public function index()
	{
  		$data2['query'] = $this->Model_crud->tampil();
  		$this->load->view('dashboard.php', $data2);
 	}

	public function tampil()
	{
		$data['query'] = $this->Model_crud->tampil();
		$this->load->view('crud_tampil', $data);
	}
	
	public function input()
	{
		$this->load->view('crud_input');
	}
	
	public function simpan()
	{
		$data = array('merek_kendaraan' => $this->input->post('merek_kendaraan'), 'nopol' => $this->input->post('nopol'));
		$proses = $this->Model_crud->simpan($data);
	if (!$proses) {
		header('location:'.base_url('index.php/crud/').$this->index());
	} else {
		echo "Data Gagal Disimpan";
		echo "<br>";
		echo "<a href='".base_url('index.php/crud/')."'>Kembali ke form</a>";
		}
	
	}
	
	public function edit()
	{
		$id = $this->uri->segment(3);
		$data['query'] = $this->Model_crud->edit($id);
		$this->load->view('crud_edit', $data);
	}
	
	public function update()
	{
		$id = $this->input->post('id');
		$data = array('merek_kendaraan' => $this->input->post('merek_kendaraan'), 'nopol' => $this->input->post('nopol'));
		$proses = $this->Model_crud->update($id, $data);
	if (!$proses) {
		header('location:'.base_url('index.php/crud/').$this->index());
	} else {
		echo "Data Gagal Diupdate";
		echo "<br>";
		echo "<a href='".base_url('index.php/crud/')."'>Tampil data</a>";
		}
	}
	
	public function hapus()
	{
		$id = $this->uri->segment(3);
		$proses = $this->Model_crud->hapus($id);
	if (!$proses) {
		redirect(base_url('index.php/crud/'));
	} else {
		echo "Data Gagal dihapus";
		echo "<br>";
		echo "<a href='".base_url('index.php/crud/')."'>Tampil data</a>";
		}
	}
	
}

