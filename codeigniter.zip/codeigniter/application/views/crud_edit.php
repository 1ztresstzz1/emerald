<!DOCTYPE html>
<html>
<body>

<form action="<?php echo base_url('index.php/crud/update'); ?>" method="POST">

<?php foreach ($query->result() as $baris) { ?>

	<h3>Edit Data Pribadi</h3>

	<input type="hidden" name="id" value="<?php echo $baris->id; ?>">


	Nama :<br>
	<input type="text" name="merek_kendaraan" value="<?php echo $baris->merek_kendaraan; ?>">

	<br>
	<br>
	E-mail<br>
	<input type="text" name="nopol" value="<?php echo $baris->nopol; ?>">

	<br><br>

	<input type="submit" value="Update">
<?php } ?>
</form> 
</body>
</html>