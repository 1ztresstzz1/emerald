<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Emerald Executive Tailor</title>

    <!-- Bootstrap core CSS -->
    <link href="<?php echo base_url();?>assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template -->
    <link href="<?php echo base_url();?>assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Varela+Round" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="<?php echo base_url();?>assets/css/grayscale.min.css" rel="stylesheet">

  </head>

  <body id="page-top">

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-light fixed-top" id="mainNav">
      <div class="container">
        <a class="navbar-brand js-scroll-trigger" href="#page-top">Emerald Executive Tailor</a>
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          Menu
          <i class="fas fa-bars"></i>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="#about">About</a>
            </li>
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="#projects">Product</a>
            </li>
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="#signup">Contact</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>

    <!-- Header -->
    <header class="masthead">
      <div class="container d-flex h-100 align-items-center">
        <div class="mx-auto text-center">
          <h1 class="mx-auto my-0 text-uppercase">EMERALD</h1>
          <h2 class="text-white-50 mx-auto mt-2 mb-5">Executive Tailor</h2>
          <a href="#about" class="btn btn-primary js-scroll-trigger">About Us</a>
        </div>
      </div>
    </header>

    <!-- About Section -->
    <section id="about" class="about-section text-center">
      <div class="container">
        <div class="row">
          <div class="col-lg-8 mx-auto">
            <h2 class="text-white mb-4">About Us</h2>
            <p class="text-white-50">Emerald Executive Tailor is one of the best and leading tailors in Jalan Veteran Selatan area. 
              With all kinds of clothing stitches and sales of international branded fabrics at standard prices. 
              Emerald Executive Tailor is able to provide satisfying services for its customers.</p>
          </div>
        </div>
        <img src="img/ipad.png" class="img-fluid" alt="">
      </div>
    </section>

    <!-- Projects Section -->
    <section id="projects" class="projects-section bg-light">
      <div class="container">

        <!-- Featured Project Row -->
        <div class="row align-items-center no-gutters mb-4 mb-lg-5">
          <div class="col-xl-8 col-lg-7">
            <img class="img-fluid mb-3 mb-lg-0" src="<?php echo base_url();?>assets/img/bg-masthead.jpg" alt="">
          </div>
          <div class="col-xl-4 col-lg-5">
            <div class="featured-text text-center text-lg-left">
              <h4>Business Shirts</h4>
              <p class="text-black-50 mb-0">Preparing for that important meeting? Or simply want to make an impression at the office? Our tailors are here to help. 
                Dressed in one of our impeccable business shirts, you’ll feel comfortable, confident and ready for whatever the day brings. 
                Button up a classic blue business dress shirt, or go all in with a custom-monogram-cuff luxury business shirt. 
                A perfect-fit business shirt immediately makes a lasting impact in interviews and pitch meetings. </p>
            </div>
          </div>
        </div>

        <!-- Project One Row -->
        <div class="row justify-content-center no-gutters mb-5 mb-lg-0">
          <div class="col-lg-6">
            <img class="img-fluid" src="<?php echo base_url();?>assets/img/demo-image-01.jpg" alt="">
          </div>
          <div class="col-lg-6">
            <div class="bg-black text-center h-100 project">
              <div class="d-flex h-100">
                <div class="project-text w-100 my-auto text-center text-lg-left">
                  <h4 class="text-white">Business Casual shirts</h4>
                  <p class="mb-0 text-white-50">Love classic business shirts but looking for something different? Prepare to step into the modern stylish world of Business Casual shirts.
                     Here we dare to try new trends and always dress impeccably with a perfect fit. Experiment by combining neutral colours with exciting contrasts and accents. 
                     Wear your custom business casual shirt with suit pants or slip on some chinos. 
                     With a business casual shirt, you're free to unleash your creativity and guaranteed to turn heads at the office.</p>
                  <hr class="d-none d-lg-block mb-0 ml-0">
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Project Two Row -->
        <div class="row justify-content-center no-gutters">
          <div class="col-lg-6">
            <img class="img-fluid" src="<?php echo base_url();?>assets/img/demo-image-02.jpg" alt="">
          </div>
          <div class="col-lg-6 order-lg-first">
            <div class="bg-black text-center h-100 project">
              <div class="d-flex h-100">
                <div class="project-text w-100 my-auto text-center text-lg-right">
                  <h4 class="text-white">Casual shirts</h4>
                  <p class="mb-0 text-white-50">Whether its a movie night, beach day, or evening at home friends, you’ll be ready for anything in a tailor-made 
                    casual shirt from Emerald Executive Tailor. Made from superior quality fabrics, our perfect fit tailor-made casual shirts are the ultimate 
                    in comfortable laid-back style. Going out but don’t know what to wear? Relax, look great and feel amazing in a casual dress shirt.
                  </p><br><p class="mb-0 text-white-50"> With so many casual shirt style options, it can be hard to know where to begin. Browse our range of 
                    Tailor Store recommended made-to-measure shirts for inspiration. We guarantee you’ll find casual shirts for all occasions. </p>
                  <hr class="d-none d-lg-block mb-0 mr-0">
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>
    </section>

    <!-- Signup Section -->
    <section id="signup" class="signup-section">
      <div class="container">
        <div class="row">
          <div class="col-md-10 col-lg-8 mx-auto text-center">

            <i class="far fa-paper-plane fa-2x mb-2 text-white"></i>
            <h2 class="text-white mb-5">Subscribe to receive updates!</h2>
            <!--CRUD -->
	<a href="<?php echo base_url('index.php/crud/input'); ?>" class="btn btn-primary mx-auto">Input Data</a>
	<br>
	<br>
  <div class="container">
  <div class="card py-4 h-100">
  <div class="card-body text-center">
	<table border="1" >
		<tr>
			<th>No.</th>
			<th>Nama</th>
			<th>E-mail</th>
			<th colspan="2">Opsi</th>
		</tr>
		<?php 

			$no = 1;
			foreach ($query->result() as $baris) {
				echo "<tr>";
				echo "<td>".$no."</td>";
				echo "<td>".$baris->merek_kendaraan."</td>";
				echo "<td>".$baris->nopol."</td>";
				echo "<td><a href=".base_url('index.php/crud/edit/').$baris->id." >Edit</a></td>";
				echo "<td ><a href=".base_url('index.php/crud/hapus/').$baris->id." >Hapus</a></td>";
				echo "</tr>";
			$no++; } 


		?>
	</table> 
  </div>
  </div>
  </div>


          </div>
        </div>
      </div>
    </section>

    <!-- Contact Section -->
    <section class="contact-section bg-black">
      <div class="container">

        <div class="row">

          <div class="col-md-4 mb-3 mb-md-0">
            <div class="card py-4 h-100">
              <div class="card-body text-center">
                <i class="fas fa-map-marked-alt text-primary mb-2"></i>
                <h4 class="text-uppercase m-0">Address</h4>
                <hr class="my-4">
                <div class="small text-black-50">Jalan Veteran Selatan No. 143, Makassar</div>
              </div>
            </div>
          </div>

          <div class="col-md-4 mb-3 mb-md-0">
            <div class="card py-4 h-100">
              <div class="card-body text-center">
                <i class="fas fa-envelope text-primary mb-2"></i>
                <h4 class="text-uppercase m-0">Email</h4>
                <hr class="my-4">
                <div class="small text-black-50">
                  <a href="#">muh.fachrularul@yahoo.co.id</a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-md-4 mb-3 mb-md-0">
            <div class="card py-4 h-100">
              <div class="card-body text-center">
                <i class="fas fa-mobile-alt text-primary mb-2"></i>
                <h4 class="text-uppercase m-0">Phone</h4>
                <hr class="my-4">
                <div class="small text-black-50">(0411) 830-800</div>
              </div>
            </div>
          </div>
        </div>

        <div class="social d-flex justify-content-center">
          <a href="#" class="mx-2">
            <i class="fab fa-twitter"></i>
          </a>
          <a href="#" class="mx-2">
            <i class="fab fa-facebook-f"></i>
          </a>
          <a href="#" class="mx-2">
            <i class="fab fa-github"></i>
          </a>
        </div>

      </div>
    </section>

    <!-- Footer -->
    <footer class="bg-black small text-center text-white-50">
      <div class="container">
        Copyright &copy; Emerald 2018
      </div>
    </footer>

    <!-- Bootstrap core JavaScript -->
    <script src="<?php echo base_url();?>assets/vendor/jquery/jquery.min.js"></script>
    <script src="<?php echo base_url();?>assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="<?php echo base_url();?>assets/vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for this template -->
    <script src="<?php echo base_url();?>assets/js/grayscale.min.js"></script>

  </body>

</html>
