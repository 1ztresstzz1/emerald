<!DOCTYPE html>
<html>
<body>

	<h2>Data Pribadi</h2>
	<a href="<?php echo base_url('index.php/crud/input'); ?>">Input Data</a>
	<br>
	<br>
	<table border="1">
		<tr>
			<th>No.</th>
			<th>Nama</th>
			<th>E-mail</th>
			<th colspan="2">Opsi</th>
		</tr>
		<?php 

			$no = 1;
			foreach ($query->result() as $baris) {
				echo "<tr>";
				echo "<td>".$no."</td>";
				echo "<td>".$baris->merek_kendaraan."</td>";
				echo "<td>".$baris->nopol."</td>";
				echo "<td><a href=".base_url('index.php/crud/edit/').$baris->id.">Edit</a></td>";
				echo "<td><a href=".base_url('index.php/crud/hapus/').$baris->id.">Hapus</a></td>";
				echo "</tr>";
			$no++; } 


		?>
	</table> 

</body>
</html>