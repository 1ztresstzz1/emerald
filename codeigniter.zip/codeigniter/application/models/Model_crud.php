<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_crud extends CI_Model
{
	public function tampil()
	{
		$query = $this->db->get('kendaraan');
		return $query;
	}
	
	public function simpan($data)
	{
		$this->db->insert('kendaraan', $data);
	}
	
	public function edit($id)
	{
		$query = $this->db->get_where('kendaraan', array('id' => $id));
		return $query;
	}	
	
	public function update($id, $data)
	{
		$this->db->update('kendaraan',$data, array('id' => $id));
	}
	
	public function hapus($id)
	{
		$this->db->where('id', $id);
		$query = $this->db->delete('kendaraan');
	}
	
}